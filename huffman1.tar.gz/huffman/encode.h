#ifndef _ENCODE_H_
#define _ENCODE_H_

int encode(const char *filename);

#endif
